# WDLMerge
Merge WDLs
## Installation
Install WDLMerge with pip
```bash
  pip install WDLMerge
```
## Requirements
* miniwdl
